var Runner;
var RunnerAnimation;

function preload(){
  //imagens pré-carregadas
  RunnerAnimation = loadAnimation("Runner-1.png", "Runner-2.png");
}

function setup(){
  createCanvas(400,400);
  //crie sprite aqui
  Runner = createSprite(200, 335, 20, 20);
  Runner.addAnimation("Running", RunnerAnimation);
  Runner.scale = 0.05;

  Faixa3 = createSprite(15, 200, 15, 400);
  Faixa3.shapeColor = ("white");

  Faixa4 = createSprite(385, 200, 15, 400);
  Faixa4.shapeColor = ("white");

}

function draw() {
  background(0);

  createFaixa();
  Runner.x = World.mouseX;

  drawSprites();
}
function createFaixa(){
  if(frameCount % 60 == 0){
    Faixa1 = createSprite(150, -50, 5, 50);
    Faixa1.velocity.y = 5;
    Faixa1.shapeColor = "white"
    Faixa1.depth = Runner.depth;

    Faixa2 = createSprite(250, -50, 5, 50);
    Faixa2.velocity.y = 5;
    Faixa2.shapeColor = "white"
    Faixa2.depth = Runner.depth;

    Runner.depth += 1;
  }
}
